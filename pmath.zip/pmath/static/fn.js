function myfunction()
{
  alert("Root found using Newton-Raphson method: ")
}

function info()
{
  alert("Information not updated yet")
}

function about()
{
  alert("A Capstone project made by the department of Mechanical Engineering.")
}